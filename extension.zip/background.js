importScripts('shared.js');

/* Right-click any selected text on any site: search the promo desk for it. */
chrome.runtime.onInstalled.addListener(() => {
  chrome.contextMenus.create({id: 'cba-search', title: 'Search promo cuts for “%s”', contexts: ['selection']});
  chrome.contextMenus.create({id: 'cba-open', title: 'Open the promo desk', contexts: ['action']});
});
chrome.contextMenus.onClicked.addListener(info => {
  if (info.menuItemId === 'cba-search' && info.selectionText) openDesk('all?q=' + encodeURIComponent(info.selectionText.trim().slice(0, 120)));
  if (info.menuItemId === 'cba-open') openDesk('queue');
});

/* Address bar: type "cut" + space + words. */
chrome.omnibox.setDefaultSuggestion({description: 'Search promo cuts for: %s'});
chrome.omnibox.onInputEntered.addListener(text => {
  const q = text.trim();
  openDesk(q ? 'all?q=' + encodeURIComponent(q) : 'queue');
});
