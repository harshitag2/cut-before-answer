const form = document.getElementById('form');
chrome.storage.sync.get(['source', 'customUrl']).then(({source = 'live', customUrl = ''}) => {
  form.source.value = source; document.getElementById('custom').value = customUrl;
});
form.onsubmit = async e => {
  e.preventDefault();
  const source = form.source.value, customUrl = document.getElementById('custom').value.trim(), saved = document.getElementById('saved');
  if (source === 'custom') {
    let url; try { url = new URL(customUrl); } catch { saved.textContent = 'Enter a full address starting with https://'; return; }
    if (url.protocol !== 'https:') { saved.textContent = 'Use an https:// address.'; return; }
    const ok = await chrome.permissions.request({origins: [url.origin + '/*']});
    if (!ok) { saved.textContent = 'Permission is needed to read that address.'; return; }
  }
  await chrome.storage.sync.set({source, customUrl});
  saved.textContent = 'Saved.';
};
