const $ = id => document.getElementById(id);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;'}[c]));
const ENDING = {arrival: 'Someone walks in', pending_action: 'About to happen', ultimatum: 'Forced choice', bombshell: 'Shock reveal', reveal_tease: 'Secret teased', unanswered_question: 'Left on a question', threat: 'Threat hanging', reaction: 'Ends on a reaction', flat: 'Weak ending', resolution: 'Gives it away'};
const STATUS = {keep: 'Approved', needs_editor: 'Second look', reject: 'Skipped', unreviewed: 'Not checked yet'};
let feed = null, tab = 'queue', desk = '';

function toast(t) { const el = $('toast'); el.textContent = t; el.classList.add('on'); clearTimeout(toast.h); toast.h = setTimeout(() => el.classList.remove('on'), 1800); }
async function copy(text, msg) { try { await navigator.clipboard.writeText(text); toast(msg); } catch { toast('Copy was blocked.'); } }
const timings = c => `Episode ${c.episode} | ${c.in} - ${c.out} | ${Number(c.seconds).toFixed(2)} s`;
const brief = c => [`PROMO BRIEF · Episode ${c.episode}${c.posting_rank ? ` · #${c.posting_rank} in the posting list` : ''}`,
  `Cut: ${c.in} – ${c.out} (${Number(c.seconds).toFixed(2)} s)`, `Opening line: "${c.opening_line}"`, `Last line: "${c.last_line}"`,
  c.leaves_wondering ? `Leaves viewers wondering: ${c.leaves_wondering}` : '', c.why ? `Why it works: ${c.why}` : '',
  c.best_for ? `Best fit: ${c.best_for}` : '', c.test_versions?.[0] ? `Also test: ${c.test_versions[0].kind.replace('_', ' ')} ${c.test_versions[0].timings}` : '',
  `Open: ${c.link}`].filter(Boolean).join('\n');
const slack = list => (list.length > 1 ? `*Promos to post* (${list.length})\n` : '') + list.map((c, i) => `*${list.length > 1 ? i + 1 + '. ' : ''}Episode ${c.episode}* · ${c.in} – ${c.out} (${Number(c.seconds).toFixed(1)} s)\n> “${c.opening_line}”${c.leaves_wondering ? `\n• Leaves them wondering: ${c.leaves_wondering}` : ''}${c.best_for ? `\n• Best for: ${c.best_for}` : ''}\n• ${c.link}`).join('\n\n');

function actions(c) { return `<div class="row-actions"><button class="main" data-act="brief" data-id="${esc(c.id)}">Copy brief</button><button data-act="times" data-id="${esc(c.id)}">Copy timings</button><button data-act="slack" data-id="${esc(c.id)}">Slack</button><button data-act="open" data-id="${esc(c.id)}">Open ↗</button></div>`; }
function render() {
  if (!feed) return;
  const pick = feed.posting_queue[0] || feed.cuts[0];
  $('pick').hidden = !pick;
  if (pick) $('pick').innerHTML = `<span class="tag">Post this first</span><h2>“${esc(pick.opening_line)}”</h2><p>Episode ${pick.episode} · ${esc(pick.in)} – ${esc(pick.out)} · ${Number(pick.seconds).toFixed(1)} s${pick.best_for ? ' · ' + esc(pick.best_for) : ''}</p>${pick.leaves_wondering ? `<p>${esc(pick.leaves_wondering)}</p>` : ''}${actions(pick)}`;
  const q = tab === 'all' ? $('search').value.trim().toLowerCase() : '';
  const pool = tab === 'queue' ? feed.posting_queue : feed.cuts.filter(c => c.status !== 'reject');
  const list = pool.filter(c => !q || q.split(/\s+/).every(w => `episode ${c.episode} ${c.opening_line} ${c.last_line} ${c.leaves_wondering}`.toLowerCase().includes(w))).slice(0, 40);
  $('list').innerHTML = list.map(c => `<li><span class="meta">${c.posting_rank ? '#' + c.posting_rank + ' · ' : ''}EP ${c.episode} · ${esc(c.in)} – ${esc(c.out)} · strength ${c.strength}<span class="chip ${c.status === 'keep' ? 'ok' : ''}">${STATUS[c.status] || ''}</span>${c.ending ? `<span class="chip">${ENDING[c.ending] || ''}</span>` : ''}</span><b>“${esc(c.opening_line)}”</b>${actions(c)}</li>`).join('');
  $('status').textContent = list.length ? '' : tab === 'queue' ? 'Nothing approved yet. Check the All cuts tab.' : 'No cuts match.';
}
async function load() {
  desk = await getDeskUrl();
  const {source = 'live'} = await chrome.storage.sync.get('source');
  $('source').textContent = source === 'custom' ? new URL(desk).host : SOURCES[source]?.label || desk;
  $('status').textContent = 'Loading…';
  try {
    const res = await fetch(desk + 'cuts.json', {cache: 'no-cache'});
    if (!res.ok) throw Error(res.status);
    feed = await res.json();
    await chrome.storage.local.set({feed, feedAt: Date.now(), feedFrom: desk});
    render();
  } catch {
    const saved = await chrome.storage.local.get(['feed', 'feedAt', 'feedFrom']);
    if (saved.feed && saved.feedFrom === desk) { feed = saved.feed; render(); $('status').textContent = `Offline: showing the list saved ${new Date(saved.feedAt).toLocaleString()}.`; }
    else $('status').textContent = source === 'local' ? 'The local desk is not running. Start it with: python src/serve.py' : "Couldn't reach the desk. Check your connection or the address in Settings.";
  }
}
document.addEventListener('click', e => {
  const b = e.target.closest('[data-act]'); if (!b || !feed) return;
  const c = feed.cuts.find(x => x.id === b.dataset.id); if (!c) return;
  if (b.dataset.act === 'brief') copy(brief(c), 'Editor brief copied.');
  if (b.dataset.act === 'times') copy(timings(c), 'Timings copied.');
  if (b.dataset.act === 'slack') copy(slack([c]), 'Copied for Slack / Teams.');
  if (b.dataset.act === 'open') chrome.tabs.create({url: c.link.startsWith('http') ? c.link : desk + c.link});
});
document.querySelectorAll('[data-tab]').forEach(b => b.onclick = () => { tab = b.dataset.tab; document.querySelectorAll('[data-tab]').forEach(x => x.setAttribute('aria-selected', String(x === b))); $('search').hidden = tab !== 'all'; if (tab === 'all') $('search').focus(); render(); });
$('search').oninput = render;
$('refresh').onclick = load;
$('settings').onclick = () => chrome.runtime.openOptionsPage();
$('open').onclick = () => openDesk('queue');
$('copy-all').onclick = () => feed && copy(slack(feed.posting_queue), 'Posting list copied for Slack / Teams.');
load();
