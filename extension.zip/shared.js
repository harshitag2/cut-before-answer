/* Settings shared by the popup, options page and background worker. */
const SOURCES = {
  live: {label: 'Live desk', url: 'https://harshitag2.github.io/cut-before-answer/'},
  local: {label: 'Local desk (this computer)', url: 'http://127.0.0.1:8765/'},
};
async function getDeskUrl() {
  const {source = 'live', customUrl = ''} = await chrome.storage.sync.get(['source', 'customUrl']);
  const url = source === 'custom' && customUrl ? customUrl : (SOURCES[source] || SOURCES.live).url;
  return url.endsWith('/') ? url : url + '/';
}
async function openDesk(hash = '') {
  const url = await getDeskUrl();
  await chrome.tabs.create({url: url + (hash ? '#' + hash : '')});
}
